<?php

use Illuminate\Database\Seeder;

class LatestGalleryImagesGalleryItemTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('gallery_images_gallery_item')->delete();
        
        \DB::table('gallery_images_gallery_item')->insert(array (
            0 => 
            array (
                'id' => '25',
                'gallery_item_id' => '1',
                'gallery_images_id' => '36',
            ),
            1 => 
            array (
                'id' => '26',
                'gallery_item_id' => '1',
                'gallery_images_id' => '37',
            ),
            2 => 
            array (
                'id' => '27',
                'gallery_item_id' => '1',
                'gallery_images_id' => '38',
            ),
            3 => 
            array (
                'id' => '28',
                'gallery_item_id' => '2',
                'gallery_images_id' => '39',
            ),
            4 => 
            array (
                'id' => '29',
                'gallery_item_id' => '2',
                'gallery_images_id' => '40',
            ),
            5 => 
            array (
                'id' => '30',
                'gallery_item_id' => '2',
                'gallery_images_id' => '41',
            ),
            6 => 
            array (
                'id' => '31',
                'gallery_item_id' => '2',
                'gallery_images_id' => '42',
            ),
            7 => 
            array (
                'id' => '32',
                'gallery_item_id' => '2',
                'gallery_images_id' => '43',
            ),
            8 => 
            array (
                'id' => '33',
                'gallery_item_id' => '2',
                'gallery_images_id' => '44',
            ),
            9 => 
            array (
                'id' => '34',
                'gallery_item_id' => '2',
                'gallery_images_id' => '45',
            ),
            10 => 
            array (
                'id' => '35',
                'gallery_item_id' => '3',
                'gallery_images_id' => '46',
            ),
            11 => 
            array (
                'id' => '36',
                'gallery_item_id' => '3',
                'gallery_images_id' => '47',
            ),
            12 => 
            array (
                'id' => '37',
                'gallery_item_id' => '3',
                'gallery_images_id' => '48',
            ),
            13 => 
            array (
                'id' => '38',
                'gallery_item_id' => '3',
                'gallery_images_id' => '49',
            ),
            14 => 
            array (
                'id' => '39',
                'gallery_item_id' => '3',
                'gallery_images_id' => '50',
            ),
            15 => 
            array (
                'id' => '40',
                'gallery_item_id' => '5',
                'gallery_images_id' => '51',
            ),
            16 => 
            array (
                'id' => '41',
                'gallery_item_id' => '5',
                'gallery_images_id' => '52',
            ),
            17 => 
            array (
                'id' => '42',
                'gallery_item_id' => '5',
                'gallery_images_id' => '53',
            ),
            18 => 
            array (
                'id' => '43',
                'gallery_item_id' => '5',
                'gallery_images_id' => '54',
            ),
            19 => 
            array (
                'id' => '44',
                'gallery_item_id' => '5',
                'gallery_images_id' => '55',
            ),
            20 => 
            array (
                'id' => '45',
                'gallery_item_id' => '6',
                'gallery_images_id' => '56',
            ),
            21 => 
            array (
                'id' => '46',
                'gallery_item_id' => '6',
                'gallery_images_id' => '57',
            ),
            22 => 
            array (
                'id' => '47',
                'gallery_item_id' => '6',
                'gallery_images_id' => '58',
            ),
            23 => 
            array (
                'id' => '48',
                'gallery_item_id' => '6',
                'gallery_images_id' => '59',
            ),
            24 => 
            array (
                'id' => '49',
                'gallery_item_id' => '7',
                'gallery_images_id' => '60',
            ),
            25 => 
            array (
                'id' => '50',
                'gallery_item_id' => '7',
                'gallery_images_id' => '61',
            ),
            26 => 
            array (
                'id' => '51',
                'gallery_item_id' => '7',
                'gallery_images_id' => '62',
            ),
            27 => 
            array (
                'id' => '52',
                'gallery_item_id' => '7',
                'gallery_images_id' => '63',
            ),
        ));
        
        
    }
}